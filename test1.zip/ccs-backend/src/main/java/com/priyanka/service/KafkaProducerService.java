
package com.priyanka.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.priyanka.entity.CreditCard;
import com.priyanka.entity.Customer;
import com.priyanka.entity.Transaction;

@Service
public class KafkaProducerService {
	
	@Value("${merchant.topic.name}")
	private String merchantTopicName;
	
	@Value("${customer.topic.name}")
	private String customerTopicName;
	
//	@Value("${last.topic.name}")
//	private String lastTopicName;
	
	@Value("${transaction.topic.name}")
	private String transactionTopicName;
	
	@Value("${creditcard.topic.name}")
	private String creditCardTopicName;
	
	private final KafkaTemplate<String, Object> kafkaTemplate;

    @Autowired
    public KafkaProducerService(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMerchantMessage( Object message) {
        kafkaTemplate.send( merchantTopicName,message);
    }
    
    public void sendCustomerMessage( Object message) {
        kafkaTemplate.send( customerTopicName,message);
    }

//	public void sendCustomersLast24hrMessage(List<Customer> customers) {
//		kafkaTemplate.send(lastTopicName ,customers);
//		
//	}
    
    
    public void sendTransactionMessage( Transaction transaction) {
        kafkaTemplate.send( transactionTopicName,transaction);
    }
    
    public void sendCreditCardMessage( CreditCard creditCard) {
        kafkaTemplate.send( creditCardTopicName,creditCard);
    }
}

