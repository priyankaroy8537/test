package com.priyanka.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.priyanka.entity.CreditCard;
import com.priyanka.entity.Customer;
import com.priyanka.entity.Merchant;
import com.priyanka.entity.Transaction;

@Service
public class kafkaConsumerService {
	
 	@Value("${merchant.topic.name}")
	private String merchantTopicName;
	
	@Value("${customer.topic.name}")
	private String customerTopicName;
	
//	@Value("${last.topic.name}")
//	private String lastTopicName;
	
	@Value("${transaction.topic.name}")
	private String transactionTopicName;
	
	@Value("${creditcard.topic.name}")
	private String creditCardTopicName;
	
	@KafkaListener(topics ="${merchant.topic.name}" , groupId ="${merchant.group.name}")
	public void consumerMessage(Merchant message) {
		System.out.println(" Recived merchant message: " + message);
	}
	
	@KafkaListener(topics ="${customer.topic.name}" , groupId ="${customer.group.name}")
	public void merchantMessage(Customer message) {
		System.out.println(" Recived customer message: " + message);
	}
	
//	@KafkaListener(topics ="${last.topic.name}" , groupId ="${last.group.name}")
//	public void consumeLastMessage(List<Customer> customers) {
//		System.out.println(" Recived list of customers created in last 24 hrs: " + customers );
//	}
	
	@KafkaListener(topics ="${transaction.topic.name}" , groupId ="${transaction.group.name}")
	public void transactionMessage(Transaction transaction) {
		System.out.println(" Recived transaction message: " + transaction);
	}
	
	
	@KafkaListener(topics ="${creditcard.topic.name}" , groupId ="${creditcard.group.name}")
	public void creditcardtMessage(CreditCard creditCard) {
		System.out.println(" Recived creditcard message: " + creditCard);
	}
	
	

}
