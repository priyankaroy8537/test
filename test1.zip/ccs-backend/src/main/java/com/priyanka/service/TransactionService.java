package com.priyanka.service;


import com.priyanka.entity.Transaction;

public interface TransactionService {
	 public Transaction postTransaction(int transactionType, String creditcardNaumber, Long merchantID,String currency,String authCode,double transactionAmount);
}
