package com.priyanka.service;

import java.util.List;
import java.util.Optional;

import com.priyanka.entity.CreditCard;
import com.priyanka.entity.Customer;

public interface CustomerService {
	 
    Customer saveCustomer(Customer customer);
    List<Customer> getAllCustomers();  

    Optional<Customer> getCustomerById(Long id); 

    void deleteCustomer(Long id);

    CreditCard issueCreditCard(Long customerId, Long productId, String maker, String checker); 
    
    List<Customer> getCustomersInLast24hr();
    Customer login(String email , String password)throws Exception;
    void updateCustomerPassword(Long id, String newPassword);
}
