 package com.priyanka.scheduler;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import com.priyanka.service.CreditCardService;

public class CreditCardTimeSheduler {
	
	private static final Logger logger= LoggerFactory.getLogger(CreditCardTimeSheduler.class);
	
  @Autowired
  private CreditCardService creditCardService;
  
  //@Scheduled(cron = "0 * * * * ?")
  @Scheduled(cron = "0 0 * * * ?")
  public void resetDaily() {
	  logger.info("Running schedued task :");
	  creditCardService.resetDailyExpense();
  }

}
