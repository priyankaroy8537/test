package com.priyanka.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;


import com.priyanka.entity.Merchant;

@Repository
public interface MerchantRepository extends JpaRepository<Merchant, Long> {
	
	@Query("Select c from Merchant c where c.merchantEmail=?1 AND c.merchantpassword=?2")
	Merchant login(String merchantEmail , String merchantpassword);
	
	@Query("Select COUNT(t) FROM Transaction t WHERE t.merchant.merchantID = ?1")
	int countTransaction(Long id);

}
