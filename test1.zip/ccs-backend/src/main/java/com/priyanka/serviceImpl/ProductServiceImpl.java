package com.priyanka.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.priyanka.entity.Product;
import com.priyanka.repository.ProductRepository;
import com.priyanka.service.ProductService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductServiceImpl implements ProductService{
	 
	@Autowired
	 private ProductRepository productRepository;

	@Override
	public Product saveProduct(Product product) {
		log.info("requesting for save products");
		// TODO Auto-generated method stub
		try { if (product.getProductType() == null ||
	            product.getProductDescription() == null || product.getProductDescription().isEmpty() ||
	            product.getProductBinValue() == null || product.getProductBinValue().length() != 6 ||
	            product.getProductSubBinValue() == null || product.getProductSubBinValue().length() != 2 ||
	            product.getProductExpiry() <= 0 ||
	            product.getProductLimit() <= 0 ||
	            product.getProductPayment() <= 0 || product.getProductPayment() > 31) {
	            throw new IllegalArgumentException("All fields are mandatory to define a product with valid constraints");
	        }
		log.info("Saving products with description " ,product.getProductDescription());
	        return productRepository.save(product); 
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error("Error saving product with description " ,product.getProductDescription());
			throw e;
		}
		
	}

	@Override
	public List<Product> getAllProducts() {
		
		// TODO Auto-generated method stub
		try {
			log.info("fetching all products ");
			return productRepository.findAll();
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error("error fetching all products ",e.getMessage(),e);
			throw e;
		}
		
	}

	@Override
	@Cacheable(cacheNames  = "productsById", key = "#id")
	public Optional<Product> getProductById(Long id) {
		// TODO Auto-generated method stub
		try {
			log.info("fetching product by id:{} ",id);
			return productRepository.findById(id);
		} catch (Exception e) {
			// TODO: handle exception
			log.error("error fetching  product by id ",e.getMessage(),e);
			throw e;
		}
		
	}

	@Override
	@CacheEvict(cacheNames  = "productsById", key = "#id")
	public void deleteProduct(Long id) {
		// TODO Auto-generated method stub
		try {
			log.info("Deleting product with id" , id);
			productRepository.deleteById(id);
		} catch (Exception e) {
			// TODO: handle exception
			log.error("error deleting  product by id ",e.getMessage(),e);
			throw e;
		}
		
		
	}

}
