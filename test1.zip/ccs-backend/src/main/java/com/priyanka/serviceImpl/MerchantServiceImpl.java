package com.priyanka.serviceImpl;

import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.priyanka.entity.Customer;
import com.priyanka.entity.Merchant;
import com.priyanka.repository.MerchantRepository;
import com.priyanka.service.KafkaProducerService;
import com.priyanka.service.MerchantService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public  class MerchantServiceImpl implements MerchantService {

	@Autowired
    private MerchantRepository merchantRepository;
	
	@Autowired
	private KafkaProducerService kafkaProducerService;

    @Override
    public Merchant saveMerchant(Merchant merchant) {
    	log.info("requesting for merchant save ");
    	try {
    		// Validate mandatory fields
    		  if (merchant.getMerchantMobile() == null || merchant.getMerchantEmail() == null) {
    	            throw new IllegalArgumentException("Mobile number and email id are mandatory fields to enroll a merchant");
    	        }
//    		// Encode the password using Base64
//    	        String encodedPassword = Base64.getEncoder().encodeToString(merchant.getMerchantpassword().getBytes());
//    	        merchant.setMerchantpassword(encodedPassword);

    	        // Generate unique merchant code 
    	        merchant.setMerchantCode(generateUniqueMerchantCode());
               log.info("Saving merchant with email", merchant.getMerchantEmail());
    	        return merchantRepository.save(merchant);
    	    
		} catch (Exception e) {
			// TODO: handle exception
			log.error("error saving merchant with email " , merchant.getMerchantEmail(),e);
			throw e;
		}
        
    }

    @Override
    public List<Merchant> getAllMerchants() {
    	try {
    		log.info("Fetching all merchants");
    		 return merchantRepository.findAll();
		} catch (Exception e) {
			// TODO: handle exception
			log.error("error fetching  merchant all merchants " , e.getMessage(),e);
			throw e;
		}
       
    }

    @Override
    @Cacheable(cacheNames = "merchants", key = "#id")
    public Optional<Merchant> getMerchantById(Long id) {
    	try {
			log.info("Fetching merchant with id {}", id);
			return merchantRepository.findById(id);
					
		} catch (Exception e) {
			// TODO: handle exception
			log.error("error fetching  merchant with id" , e.getMessage(),e);
			throw e;
		}
        
    }

    @Override
    @CacheEvict(cacheNames = "merchants", key = "#id")
    public void deleteMerchant(Long id) {
    	try {
    		log.info("deleting merchant with id", id);
    		  merchantRepository.deleteById(id);
		} catch (Exception e) {
			// TODO: handle exception
			log.error("error deleting  merchant with id" , e.getMessage(),e);
			throw e;
		}
      
    }

    private String generateUniqueMerchantCode() {
        
        return String.valueOf((int) (Math.random() * 9000000) + 1000000);
    }

	@Override
	@Cacheable(cacheNames = "merchants", key = "#merchantEmail" )
	public Merchant login(String merchantEmail, String merchantpassword) throws Exception {
		try {
			log.info("trying to login merchant with email: {}" , merchantEmail);
			Merchant merchant= merchantRepository.login(merchantEmail, merchantpassword);
			
//			// Encode the password using Base64 for comparison
//	        String encodedPassword = Base64.getEncoder().encodeToString(merchantpassword.getBytes());
//	        
//	        Merchant merchant = merchantRepository.login(merchantEmail, encodedPassword);
	        
			if(merchant== null) {
				log.warn("invalid login " ,merchantEmail);
				throw new Exception("invalid email or Password ");
			}
			kafkaProducerService.sendMerchantMessage( merchant);
			return merchant;
		} catch (Exception e) {
			// TODO: handle exception
			log.error("Error logging in merchant with email " , merchantEmail, e.getMessage(),e);
			throw e;
		}
		// TODO Auto-generated method stub
		
	}

	@Override
	public int countTransaction(Long id) {
		// TODO Auto-generated method stub
		return merchantRepository.countTransaction(id);
	}

	
}
