package com.priyanka.serviceImpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.priyanka.entity.CreditCard;
import com.priyanka.repository.CreditCardRepository;
import com.priyanka.service.CreditCardService;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class CreditCardServiceImpl implements CreditCardService{
	private static final Logger logger= LoggerFactory.getLogger(CreditCardServiceImpl.class); 
	
	@Autowired
	private CreditCardRepository creditCardRepository;

	@Override
	@Cacheable(cacheNames  = "creditCardsByNumber", key = "#number")
	public CreditCard getByNumber(String number) {
		try {
			log.info("Fetching credit card with number :{}", number);
			CreditCard creditcard=creditCardRepository.getByNumber(number);
			
			if(creditcard == null) {
				log.warn("Crad number is not found", number);
			}
			return creditcard;
		} catch (Exception e) {
			// TODO: handle exception
			log.error("Error fetching credit card with number " , number , e.getMessage());
			throw e;
			
		}
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resetDailyExpense() {
		try {
			log.info("Resetting daily expenses for all credit card");
			List<CreditCard> creditCards= creditCardRepository.findAll();
			for(CreditCard creditCard : creditCards) {
				creditCard.setDailyExpence(0);
				creditCardRepository.save(creditCard);
			}
			log.info("reset all the credit cards successfully");
		
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error("Error resetting daily expenses for credit cards :" , e.getMessage(),e);
			throw e;
		}
		//logger.info("Reset daily expenses for all credit cards");
		// TODO Auto-generated method stub
	}	

}
