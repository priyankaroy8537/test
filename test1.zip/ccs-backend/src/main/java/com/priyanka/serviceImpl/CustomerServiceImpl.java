package com.priyanka.serviceImpl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.priyanka.constants.CustomerConstants;
import com.priyanka.entity.CardType;
import com.priyanka.entity.CreditCard;
import com.priyanka.entity.Customer;
import com.priyanka.entity.Product;
import com.priyanka.repository.CreditCardRepository;
import com.priyanka.repository.CustomerRepository;
import com.priyanka.repository.ProductRepository;
import com.priyanka.service.CustomerService;
import com.priyanka.service.KafkaProducerService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CustomerServiceImpl implements CustomerService {
	 @Autowired
	    private CustomerRepository customerRepository;

	    @Autowired
	    private ProductRepository productRepository;

	    @Autowired
	    private CreditCardRepository creditCardRepository;
	    
	    @Autowired
	    private KafkaProducerService kafkaProducerService;
	    

	    @Override
	    public Customer saveCustomer(@Valid Customer customer) {
	    log.info("request recived from customer to save customer details " + customer.getCustomerID());
	    try {
	        // Validate 
	        if (customer.getPan() == null || customer.getMobile() == null || customer.getEmail() == null) {
	            throw new IllegalArgumentException("PAN, mobile  and email id are mandatory fields to issue a credit card");
	        }
	        log.info("saving customer with pan , mobile and email " ,customer.getPan(), customer.getMobile(),customer.getEmail());
	        
	     // Encode the password using Base64
	        String encodedPassword = Base64.getEncoder().encodeToString(customer.getPassword().getBytes());
	        customer.setPassword(encodedPassword);
	        
	        return customerRepository.save(customer);
	    
	    }catch (Exception e) {
	    	log.error("Error while saving customer :" , e.getMessage(),e);
	    	return null ;
	    }
		
	    }

	    @Override
	    public List<Customer> getAllCustomers() {
	    	 log.info("request recived from customer to get all customer details " );
	    	 try {
				log.info("Fetching all customers" );
				return customerRepository.findAll();
			} catch (Exception e) {
				// TODO: handle exception
				log.error("Error fetching all customer " ,e.getMessage(),e);
				throw e;
			}
			
	        
	    }

	    @Override
	    @Cacheable(cacheNames = "customers" ,key ="#id")
	    public Optional<Customer> getCustomerById(Long id) {
	    	log.info("request recived from customer to get customer details by id " );
	    	try {
				log.info("fetching customer by Id :{}", id);
				 return customerRepository.findById(id);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("Error fetching customer by Id : " ,e.getMessage(),e);
				throw e;
			}
	       
	    }

	    @Override
	    @CacheEvict(cacheNames = "customers" ,key="#id")
	    public void deleteCustomer(Long id) {
	    	
	    	log.info("request recived for deleting of customer");
	    	try {
	    		log.info("Deleting customer by id :" , id);
	    		customerRepository.deleteById(id);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("Error deleting customer by id" , e.getMessage(), e);
				throw e;
			}
	        
	    }

	    @Override
	    public CreditCard issueCreditCard(Long customerId, Long productId, String maker, String checker) {
	    	log.info("request issue a credit card customer");
	    	try {
	    		 Customer customer = customerRepository.findById(customerId)
	 	                .orElseThrow(() -> new IllegalArgumentException("Customer not found"));

	 	        Product product = productRepository.findById(productId)
	 	                .orElseThrow(() -> new IllegalArgumentException("Product not found"));

	 	       
	 	        String cardNumberPrefix;
	 	        if (product.getCardType()== CardType.VISA) {
	 	            cardNumberPrefix =CustomerConstants.VISA_PREFIX;
	 	        } else if (product.getCardType()== CardType.MASTERCARD) {
	 	            cardNumberPrefix = CustomerConstants.MASTERCARD_PREFIX;
	 	        } else {
	 	            throw new IllegalArgumentException("Unsupported card type");
	 	        }

	 	        String cardNumber = cardNumberPrefix + generateCardNumberSequence();
	 	      
	 	      
	 	        LocalDate expiryDate = LocalDate.now().plusMonths(product.getProductExpiry());
	 	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYMM");
	 	        String expiryDateFormatted = expiryDate.format(formatter); 

	 	      
	 	        CreditCard creditCard = new CreditCard(productId, expiryDateFormatted, expiryDate, 0, productId, expiryDateFormatted, expiryDateFormatted, expiryDateFormatted,0, customer, product);
	 	        creditCard.setCreditcardNumber(cardNumber);
	 	        creditCard.setCreditcardExpiry(expiryDate);
	 	        creditCard.setCvv((int) (Math.random() * 900) + 100); 
	 	        creditCard.setCreditLimit(product.getProductLimit());
	 	        creditCard.setCreditcardstatus("open"); 
	 	        creditCard.setMaker(maker);
	 	        creditCard.setChecker(checker);
	 	        creditCard.setCustomer(customer);
	 	        creditCard.setProduct(product);
	 	        creditCard.setDailyExpence(0);

	 	       CreditCard savedCreditCard= creditCardRepository.save(creditCard);
	 	       kafkaProducerService.sendCreditCardMessage(savedCreditCard);
	 	       return savedCreditCard;
				
			} catch (Exception e) {
				// TODO: handle exception
				log.error("Error issuing credit card" , e.getMessage(), e);
				throw e;
				
			}
	       
	    }

	    private String generateCardNumberSequence() {
	       
	        long number = (long) (Math.random() * 1_000_000_000_000_000L);
	        return String.format("%015d", number);
	    }

		@Override
		@Cacheable(cacheNames = "customers")
		public List<Customer> getCustomersInLast24hr() {
			log.info("requesting fetching store customer last 24 hours");
			try {
				LocalDateTime day =LocalDateTime.now().minusDays(1);
				log.info("Fetching customer created in the last 24 hrs");
				
//				List<Customer> customers= customerRepository.findAllByCreatedAfter(day);
//				kafkaProducerService.sendCustomersLast24hrMessage(customers);
//				return customers;
				
				
				return customerRepository.findAllByCreatedAfter(day);
			}catch (Exception e) {
				log.error("Error fetching customers created in the last 24 hours :" , e.getMessage(),e);
				throw e;
				
			}
				
		}

		@Override
		//@Cacheable(cacheNames = "customers" ,key ="#email" )
		public Customer login(String email, String password) throws Exception {
			log.info("requsting for log in ");
			try {
				log.info("Logging in customer with email {}" ,email);
				//Customer customer=customerRepository.login(email, password);
				 // Encode the password using Base64 for comparison
		        String encodedPassword = Base64.getEncoder().encodeToString(password.getBytes());
		        
		        Customer customer = customerRepository.login(email, encodedPassword);
				if(customer == null) {
					throw new Exception("Invalid email or password");
				}
				
				kafkaProducerService.sendCustomerMessage(customer);
				return customer;      
				
			}catch (Exception e) {
				// TODO: handle exception
				log.error("Error logging in customer ", e.getMessage(),e);
				throw e;
			}
			// TODO Auto-generated method stub
			
		}

		@Override
		@CachePut(cacheNames = "customers" ,key ="#id")
		public void updateCustomerPassword(Long id, String newPassword) {
			// TODO Auto-generated method stub
			Optional<Customer> optionalCustomer =customerRepository.findById(id);
			log.info("requsting for update passwor for customer : {} " ,id);
			if(optionalCustomer.isPresent()) {
				Customer customer=optionalCustomer.get();
				customer.setPassword(newPassword); 
				customerRepository.save(customer); 
				log.info("update password for customer id : {}" ,id);
				
			}else {
				throw new IllegalArgumentException("Customer not found");
			}
			
		}
}
