package com.priyanka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.priyanka.entity.CreditCard;
import com.priyanka.service.CreditCardService;

@RestController
@RequestMapping("/credit-card-details")
@CrossOrigin
public class CreditCardController {
	@Autowired
  private CreditCardService creditCardService;
	
	@GetMapping("/details")
	public CreditCard getCreditCardDetails(@RequestParam String number) {
		return creditCardService.getByNumber(number);
		
	}
}
