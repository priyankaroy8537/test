package com.priyanka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.priyanka.service.CreditCardService;
@RestController
public class TestController {
	
@Autowired
 private CreditCardService creditCardService;
@GetMapping("/test-reset")
public String testResetDailyExpense() {
	creditCardService.resetDailyExpense();
	return "Daily expenses reset successfully";
	
}
}
