package com.priyanka.constants;

public class CustomerConstants {
 public static final String VISA_PREFIX="4";
 public static final String MASTERCARD_PREFIX="5";
}
