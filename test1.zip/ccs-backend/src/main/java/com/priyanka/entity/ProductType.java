package com.priyanka.entity;

public enum ProductType {
  GOLD ,
  PLATINUM,
  TITANIUM
}
  