package com.priyanka.entity;

public enum CustomerStatus {
	 ACTIVE,
	 CLOSED


}
