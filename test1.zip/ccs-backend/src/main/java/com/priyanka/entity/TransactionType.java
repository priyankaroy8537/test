package com.priyanka.entity;

public enum TransactionType {
 BalanceEnquiry,
 Purchases,
 Payments,
 Cancellation
}
