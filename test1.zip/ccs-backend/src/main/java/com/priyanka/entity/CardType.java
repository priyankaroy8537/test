package com.priyanka.entity;

public enum CardType {
 VISA,
 MASTERCARD 
}
