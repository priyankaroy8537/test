package com.priyanka.entity;

public enum MerchantStatus {
 ACTIVE,
 CLOSED
}
